# Money Control — cómo dejarla instalada en tu celular

Esta carpeta es la app completa. Para instalarla en el teléfono hay que ponerla en una
dirección web (una PWA no se instala desde un archivo suelto, necesita https). Es gratis y
son unos 10 minutos la primera vez.

```
money-control-pwa/
├── index.html            ← toda la app
├── manifest.webmanifest  ← nombre, colores e íconos
├── sw.js                 ← hace que funcione sin internet
└── icons/                ← íconos de la app
```

Antes de subirla puedes abrir `index.html` con doble clic para revisarla. Así funciona todo
menos la instalación, que necesita el paso siguiente.

---

## Opción 1 — Netlify Drop (la más rápida, sin terminal)

1. Entra a **app.netlify.com/drop**
2. Arrastra la carpeta `money-control-pwa` completa a la ventana
3. Te da una dirección tipo `https://algo-random-123.netlify.app`
4. Crea la cuenta gratis cuando te lo pida (con GitHub o correo), si no el sitio se borra
   en unas horas. En *Site configuration → Change site name* puedes dejarla como
   `money-control-sebastian.netlify.app` o lo que quieras.

## Opción 2 — GitHub Pages (si ya usas GitHub)

1. Crea un repositorio público nuevo, por ejemplo `money-control`
2. Sube el **contenido** de esta carpeta a la raíz del repo (index.html, manifest, sw.js y la
   carpeta icons). Ojo: el contenido, no la carpeta dentro de otra carpeta.
3. *Settings → Pages → Source: Deploy from a branch → main → /(root) → Save*
4. En un par de minutos queda en `https://tuusuario.github.io/money-control/`

Las dos opciones dan https, que es lo único que la instalación exige.

---

## Instalarla en el teléfono

**Android (Chrome):** abre la dirección. Arriba a la derecha aparece un botón
**Instalar app**; si no, usa el menú ⋮ → *Instalar aplicación* o *Agregar a pantalla
principal*.

**iPhone (Safari):** abre la dirección, toca el botón **Compartir** (el cuadrito con la
flecha) y elige **Añadir a pantalla de inicio**. La app misma te muestra ese recordatorio la
primera vez. Tiene que ser Safari: desde Chrome en iPhone no se puede.

**En el computador:** Chrome muestra un ícono de instalar en la barra de direcciones, y te
deja la app en ventana propia.

Queda con ícono propio, abre en pantalla completa sin barra de navegador, y funciona sin
internet.

**Cómo se usa en el teléfono:** abajo hay una barra con *Este mes* y *Histórico*, y al medio
el botón **+**. Ese botón sube la hoja para anotar el gasto: monto, categoría (tocas una o
escribes una nueva), detalle y fecha. Al guardar, la hoja se cierra sola y aparece abajo un
aviso con **Deshacer** por si te equivocaste. Para borrar un gasto ya anotado, el basurero
al lado derecho de cada movimiento — también con Deshacer.

---

## Sobre tus datos

Los gastos se guardan **dentro del dispositivo donde anotas**, no en internet. Entonces:

- Funciona sin conexión, siempre, y nadie más ve tus datos.
- El celular y el computador llevan cuentas separadas: no se sincronizan solos.
- Si borras los datos del navegador o desinstalas la app, se van con ella.

Por eso en la pestaña **Histórico** hay un bloque de respaldo:

- **Descargar respaldo** te deja un archivo `.json` con todo.
- **Copiar respaldo** lo manda al portapapeles.
- **Restaurar respaldo** lo pega de vuelta, y eliges entre *sumar* lo que falte o
  *reemplazar* todo.

Para traerte lo que ya tienes anotado en la versión de Claude: ábrela en el computador,
Histórico → **Copiar respaldo**, mándatelo por WhatsApp, y en la app del celular
Histórico → **Restaurar respaldo** → pegar → *Reemplazar todo*.

Es buena costumbre descargar un respaldo una vez al mes.

---

## Si después le cambias algo

Editas `index.html`, vuelves a subir el archivo, y **súbele el número de versión en
`sw.js`** (la línea `var CACHE = "money-control-v1";` pasa a `v2`). Si no lo haces, el
celular sigue mostrando la versión vieja que tiene guardada.

## Detalle menor

Las tipografías se bajan de Google Fonts la primera vez que abres la app con internet y
después quedan guardadas. Si la abres sin conexión desde el arranque, se ve con las
tipografías del sistema: funciona igual, solo cambia un poco el aspecto.
